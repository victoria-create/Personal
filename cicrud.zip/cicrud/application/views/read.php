<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Product Catalog</title>  
	<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
<style>

#myInput {
  box-sizing: border-box;  
  background-position: 14px 12px;
  background-repeat: no-repeat;
  font-size: 16px;
  padding: 14px 20px 12px 45px;
  border: none;
  border-bottom: 2px solid #FF8C00;
  
}

#myInput:focus {outline: 1px solid #FF8C00;}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f6f6f6;
  min-width: 230px;
  overflow: auto;
  border: 1px solid #FF8C00;
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}
</style>
</head>
<body>
<div class="container">
<div class="row">
<div class="col-md-12">
<h3 style="color:orange">Product Catalog Module</h3> 
<h3 style="color:blue;float: right;margin-top: -13px;text-size-adjust: 16px;font-size: 11px;">CodeIgniter Framework</h3> 
<hr/>
<!--- Success Message --->
<?php if ($this->session->flashdata('success')) { ?> 
<p style="font-size: 20px; color:green"><?php echo $this->session->flashdata('success'); ?></p>
<?php }?>
<!---- Error Message ---->
<?php if ($this->session->flashdata('error')) { ?>
<p style="font-size: 20px; color:red"><?php echo $this->session->flashdata('error'); ?></p>
 <?php } ?> 
<?php //echo base_url();exit; ?>
<a href="<?php echo site_url('insert'); ?>">
<button class="btn btn-primary" > Insert Record</button></a><h2></h2>

  
<div class="table-responsive">                
<table id="mytable" class="table table-bordred table-striped">                 
<thead>
<th>#</th>
<th>Product Name</th>
<th>Product Code</th>
<th>Category</th>
<th>Description</th>
<th>Posting Date</th>
<th>Edit</th>
<th>Delete</th>
</thead>
<h2></h2>
<tbody>    
<?php 
$cnt=1;
if(!empty($result)){
foreach($result as $row)
{               
?>  
    <tr>
    <td><?php echo htmlentities($cnt);?></td>
    <td><?php echo htmlentities($row->product_name);?></td>
    <td><?php echo htmlentities($row->product_code);?></td>
    <td><?php echo htmlentities($row->category);?></td>
    <td><?php echo htmlentities($row->description);?></td>
    <td><?php echo htmlentities($row->PostingDate);?></td>
    <td>
<?php 
//for passing row id to controller
echo  anchor("Read/getdetails/{$row->id}",' ','class="btn btn-success btn-xs glyphicon glyphicon-pencil"')?>
</td>
<td>
<?php 
//for passing row id to controller
echo anchor("Delete/index/{$row->id}",' ','class="glyphicon glyphicon-trash btn-danger btn-xs"')?>
</td>
</tr>
<?php 
// for serial number increment
$cnt++;
} }else{?>
 <td>No Records Found</td>
<?php } ?>
</tbody>      
</table>
</div>
</div>
</div>
</div>
</body>
</html>
