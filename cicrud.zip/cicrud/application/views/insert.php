<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Product Catalog</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" integrity="sha384-fLW2N01lMqjakBkx3l/M9EahuwpSfeNvV63J5ezn3uZzapT0u7EYsXMjQV+0En5r" crossorigin="anonymous">
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
</head>
<body>

<div class="container">
<div class="row">
<div class="col-md-12">
<h3 style="color:orange">Insert Record |  Product Catalog</h3>
<hr />
</div>
</div>
	
<?php echo form_open('',['name'=>'insertdata','autocomplete'=>'off']);?>
<div class="row">
<div class="col-md-4"><b>First Name</b>
<?php echo form_input(['name'=>'product_name','class'=>'form-control','value'=>set_value('product_name')]);?>
<?php echo form_error('product_name',"<div style='color:red'>","</div>");?>
</div>
<div class="col-md-4"><b>Product Code</b>
<?php echo form_input(['name'=>'product_code','class'=>'form-control','value'=>set_value('product_code')]);?>
<?php echo form_error('product_code',"<div style='color:red'>","</div>");?>

</div>
</div><h2></h2>
<div class="row">
<div class="col-md-4"><b>Category</b>
<?php echo form_input(['name'=>'category','class'=>'form-control','value'=>set_value('category')]);?>
<?php echo form_error('category',"<div style='color:red'>","</div>");?>

</div>
</div><h2></h2> 
<div class="row">
<div class="col-md-8"><b>Description</b>
<?php echo form_textarea(['name'=>'description','class'=>'form-control','value'=>set_value('description')]);?>
<?php echo form_error('description',"<div style='color:red'>","</div>");?>
</div>
</div>  

<div class="row" style="margin-top:1%">
<div class="col-md-8">
<?php echo form_submit(['name'=>'insert','class'=>'btn-success','value'=>'Submit']);?>	
<button class="btn-primary"><a style="text-decoration: none;color:white;" href="<?=base_url();?>">Back</a></button>
</div>
</div> 
  
<?php echo form_close();?>       
</div>
</div>
</body>
</html>