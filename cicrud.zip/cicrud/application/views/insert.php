<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>CURD Operation using CodeIgniter  </title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo link_tag('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css'); ?>
    <script src="<?php echo base_url('https://code.jquery.com/jquery-1.11.1.min.js'); ?>"></script>
    <script src="<?php echo base_url('https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js'); ?>"></script>
</head>
<body>

<div class="container">
<div class="row">
<div class="col-md-12">
<h3>Insert Record |  CRUD Operations using CodeIgniter</h3>
<hr />
</div>
</div>
	
<?php echo form_open('',['name'=>'insertdata','autocomplete'=>'off']);?>
<div class="row">
<div class="col-md-4"><b>First Name</b>
<?php echo form_input(['name'=>'product_name','class'=>'form-control','value'=>set_value('product_name')]);?>
<?php echo form_error('product_name',"<div style='color:red'>","</div>");?>
</div>
<div class="col-md-4"><b>Product Code</b>
<?php echo form_input(['name'=>'product_code','class'=>'form-control','value'=>set_value('product_code')]);?>
<?php echo form_error('product_code',"<div style='color:red'>","</div>");?>

</div>
</div><h2></h2>
<div class="row">
<div class="col-md-4"><b>Category</b>
<?php echo form_input(['name'=>'category','class'=>'form-control','value'=>set_value('category')]);?>
<?php echo form_error('category',"<div style='color:red'>","</div>");?>

</div>
</div><h2></h2> 
<div class="row">
<div class="col-md-8"><b>Description</b>
<?php echo form_textarea(['name'=>'description','class'=>'form-control','value'=>set_value('description')]);?>
<?php echo form_error('description',"<div style='color:red'>","</div>");?>
</div>
</div>  

<div class="row" style="margin-top:1%">
<div class="col-md-8">
<?php echo form_submit(['name'=>'insert','class'=>'btn-success','value'=>'Submit']);?>	
<button class="btn-primary"><a style="text-decoration: none;color:white;" href="<?=base_url();?>">Back</a></button>
</div>
</div> 
  
<?php echo form_close();?>       
</div>
</div>
</body>
</html>