<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insert extends CI_Controller {
// For data insertion	
public function index(){
$this->form_validation->set_rules('product_name','Product Name','required');	
$this->form_validation->set_rules('product_code','Product Code','required');	
$this->form_validation->set_rules('category','Category','required');	
$this->form_validation->set_rules('description','Description','required');		

if($this->form_validation->run()){
$pname=$this->input->post('product_name');
$pcode=$this->input->post('product_code');
$category=$this->input->post('category');
$des=$this->input->post('description');
$this->load->model('Insert_Model');
$this->Insert_Model->insertdata($pname,$pcode,$category,$des);
$this->load->view('insert');
} else {
$this->load->view('insert');
}
}

// For data updation
public function updatedetails(){
$this->form_validation->set_rules('product_name','Product Name','required');	
$this->form_validation->set_rules('product_code','Product Code','required');	
$this->form_validation->set_rules('category','Category','required');	
$this->form_validation->set_rules('description','Description','required');	

if($this->form_validation->run()){
$pname=$this->input->post('product_name');
$pcode=$this->input->post('product_code');
$category=$this->input->post('category');
$des=$this->input->post('description');
$usid=$this->input->post('userid');
$this->load->model('Insert_Model');
$this->Insert_Model->updatedetails($pname,$pcode,$category,$des,$usid);
} else {
$this->session->set_flashdata('error', 'Somthing went worng. Try again with valid details !!');
		redirect('read');
}
}

}