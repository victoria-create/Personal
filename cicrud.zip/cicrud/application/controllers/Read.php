<?php
defined('BASEPATH') OR exit('No direct script access allowed'); 

class Read extends CI_Controller{
	
	function __construct() 
	{
		parent::__construct();
		
		$this->load->model('Read_Model');
	}
	
	// for all records
	public function index(){
	
	$results=$this->Read_Model->getdata();
	$this->load->view('read',['result'=>$results]);
	}
	// for particular recod
	public function getdetails($uid)
	{
	
	$reslt=$this->Read_Model->getuserdetail($uid);
	$this->load->view('update',['row'=>$reslt]);
	}
	public function get_category($uid)
	{
	
	$reslt=$this->Read_Model->getuserdetail($uid);
	$this->load->view('update',['row'=>$reslt]);
	}
}